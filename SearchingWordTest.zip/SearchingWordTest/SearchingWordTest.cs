﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SearchingWord;

namespace SearchingWord.Test
{
    [TestClass]
    public class MatchingWordTest
    {
        [TestMethod]
        public void WordExist_ReturnsTrue_WhenWordExists()
        {
            // Arrange
            var board = new char[][]
            {
                new char[] { 'A', 'B', 'C', 'E' },
                new char[] { 'S', 'F', 'C', 'S' },
                new char[] { 'A', 'D', 'E', 'E' }
            };
            var word = "ABCCED";
            var matcher = new MatchingWord();

            // Act
            var result = matcher.WordExist(board, word);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void WordExist_ReturnsFalse_WhenWordDoesNotExist()
        {
            // Arrange
            var board = new char[][]
            {
                new char[] { 'A', 'B', 'C', 'E' },
                new char[] { 'S', 'F', 'C', 'S' },
                new char[] { 'A', 'D', 'E', 'E' }
            };
            var word = "NOTFOUND";
            var matcher = new MatchingWord();

            // Act
            var result = matcher.WordExist(board, word);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void WordExist_ReturnsFalse_WhenWordRequiresCellReuse()
        {
            // Arrange
            var board = new char[][]
            {
                new char[] { 'A', 'B' },
                new char[] { 'C', 'D' }
            };
            var word = "ABCDAB";
            var matcher = new MatchingWord();

            // Act
            var result = matcher.WordExist(board, word);

            // Assert
            Assert.IsFalse(result); 
        }
    }
}
