﻿using System;

namespace SearchingWord
{
    public class MatchingWord
    {
        public bool WordExist(char[][] cBoard, string nWord)
        {
            int nRows = cBoard.Length;
            for (int i = 0; i < nRows; i++)
            {
                int nCols = cBoard[i].Length;

                for (int j = 0; j < nCols; j++)
                {
                    if (DepthSearch(cBoard, nWord, i, j, 0))
                        return true;
                }
            }

            return false;
        }

        private bool DepthSearch(char[][] cBoard, string strWord, int nRows, int nCols, int nIndex)
        {
            if (nIndex == strWord.Length) return true;

            if (nRows < 0 || nRows >= cBoard.Length ||nCols < 0 || nCols >= cBoard[0].Length || cBoard[nRows][nCols] != strWord[nIndex])
                return false;

            char temp = cBoard[nRows][nCols];
            cBoard[nRows][nCols] = 'V';

            bool found = DepthSearch(cBoard, strWord, nRows + 1, nCols, nIndex + 1) ||
                         DepthSearch(cBoard, strWord, nRows - 1, nCols, nIndex + 1) ||
                         DepthSearch(cBoard, strWord, nRows, nCols + 1, nIndex + 1) ||
                         DepthSearch(cBoard, strWord, nRows, nCols - 1, nIndex + 1);

            cBoard[nRows][nCols] = temp; //Backtracking
            return found;
        }
    }
}
