﻿namespace StudentAverageMarks
{
    public class CaculateAverageMarks
    {
        public string Name {  get; set; }
        public int RollNo {  get; set; }
        public int Marks {  get; set; }

        public CaculateAverageMarks(string name,int rollno,int mark)
        {
            Name = name;
            RollNo = rollno;
            Marks = mark;
        }
        public static int AverageMarks(int[] marks)
        {
            int Sum = 0;
            foreach(int value in marks)
            {
                Sum += value;
            }
            return Sum / marks.Length;
        }
    }
}